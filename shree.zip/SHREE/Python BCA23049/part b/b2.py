class BankAccount:
    def __init__(self):
        self.bal=0

    def deposit(self,amt):
        if amt<0:
            print("invalid amount")
        else :
            self.bal+=amt
            print(f"{amt} rupees is deposited")

    def withdraw(self,amt):
        if amt<0:
            print("enter valid amount")

        elif self.bal<amt:
            print("insufficient balance")
        else:
            self.bal-=amt
            print(f"{amt} rupees withdrawn")

    def getbalance(self):
        return self.bal

class SavingsAccount(BankAccount):
    def __init__(self):
        super().__init__()
        self.rate=0

    def Updaterate(self,rate):
        if rate <0:
            print("enter valid rate")
        else:
            self.rate=rate
            print("interest rate accepted")

    def compute(self):
        int_amt=(self.bal*self.rate//100)
        self.bal+=int_amt
        print(f"interest rate is {self.rate}")

MyAccount=SavingsAccount()
while True:
    print("1.Deposit\n 2.withdraw\n 3.get balance\n 4.interest rate\n 5.calc interest\n 6.exit")
    ch=int(input("enter your choice:"))
    if ch==1:
        amt=int(input("enter amount to deposit:"))
        MyAccount.deposit(amt)
    elif ch==2:
        amt=int(input("enter amount to withdraw"))
        MyAccount.withdraw(amt)

    elif ch==3:
        amt=MyAccount.getbalance()
        print(f"available balance amount:{amt}")
    elif ch==4:
        rate=float(input("enter interest rate:"))
        MyAccount.Updaterate(rate)
    elif ch==5:
        MyAccount.compute()
    elif ch==6:
        print("exiting....")
        break
    else:
        print("wrong choice!")






