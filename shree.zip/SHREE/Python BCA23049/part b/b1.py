class Employee:
    def __init__(self, a1, a2, a3, a4, a5, a6):
        self.num = a1
        self.name = a2
        self.dept = a3
        self.des = a4
        self.age = a5
        self.salary = a6

    def display_emp(self):
        print(f"employee no :{self.num}", end=", ")
        print(f"name: {self.name}", end=", ")
        print(f"department: {self.dept}", end=", ")
        print(f"designation: {self.des}", end=", ")
        print(f"salary: {self.salary}\n")


def read_emp(n):
    employees = []
    for i in range(n):
        print(f"enter the details for {i + 1} employee")
        e_num = int(input("enter employee number: "))
        e_name = input("enter name: ")
        e_dept = input("enter department: ")
        e_des = input("enter designation: ")
        e_age = int(input("enter age: "))
        e_salary = int(input("enter salary: "))
        employee = Employee(e_num, e_name, e_dept, e_des, e_age, e_salary)
        employees.append(employee)
    return employees


def search_emp(employees, empno):
    for emp in employees:
        if emp.num == empno:
            return emp
    return None


def main():
    employees = []
    while True:
        print("\n1. Add Data")
        print("2. Search Employee")
        print("3. Display All Employees")
        print("4. Exit")

        ch = int(input("Enter your choice: "))

        if ch == 1:
            n = int(input("enter number of employees: "))
            employees = read_emp(n)
        elif ch == 2:
            search = int(input("enter the number to search: "))
            employee = search_emp(employees, search)
            if employee:
                print("\nEmployee found:")
                employee.display_emp()
            else:
                print("Employee not found.")
        elif ch == 3:
            print("\nAll employee details:")
            if not employees:
                print("No employee data available.")
            for emp in employees:
                emp.display_emp()
        elif ch == 4:
            print("Exiting program...")
            break
        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()






