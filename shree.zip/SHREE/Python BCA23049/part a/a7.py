class TooHighException(Exception):
    pass
class TooLowException(Exception):
    pass
class CorrectException(Exception):
    pass

def guess_number():
    stored_number=42
    while True:
        try:
            user_input=input("enter your guess")
            guess=int(user_input)
            if guess>stored_number:
                raise TooHighException
            elif guess<stored_number:
                raise TooLowException
            else:
                raise CorrectException
        except TooHighException:
            print("your guess is too high")
        except TooLowException:
            print("your guess is Too low")
        except CorrectException:
            print("congratulations your guess is correct number")
            break
        except ValueError:
            print("please enter a valid integer")

guess_number()




