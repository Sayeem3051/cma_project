words = 0
lines = 0
chars = 0

f = open("Examplee.Txt",'w')
f.write("today is monday\n tomorrow is Tuesday")
f.close()

with open(r"Examplee.Txt",'r')as fp:
    lines =len(fp.readlines())
print("number of lines:",lines)

with open(r"Examplee.Txt",'r')as fp:
    for line in fp:
        temp=line.split()
        words +=len(temp)
print("number of words:",words)

with open(r"Examplee.Txt",'r')as fp:
    data=fp.read()
    chars=len(data)
print("number of characters",chars)


