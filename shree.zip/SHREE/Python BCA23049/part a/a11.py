def find_unique(checklist):
    unique_list=[]
    for item in checklist:
        if item not in unique_list:
            unique_list.append(item)
    return unique_list

def unique(listA):
    unique = []
    for ele in listA:
        c = ListA.count(ele)
        if c==1:
            unique.append(ele)
    return unique

N = int (input("enter the number of elements in the list"))

ListA=[]
print(f"enter any {N} elements")
for i in range(N):
    element=input("enter an element")
    ListA.append(element)

List_Unique=find_unique(ListA)

print("The unique elements are ",List_Unique)

uniquelist=unique(ListA)
print("Unique list is :\n",uniquelist)

