def area_rect(l,b):
    ar = l * b
    print(f"area of rectangle is :{ar}")

def area_Square(s):
    ar = s * s
    print(f"area of the square is {ar}")

def area_circle (r):
    ar = 3.14 * (r*r)
    print(f"area of the circle are {ar}")

def area_triangle(b,h):
    ar = (b * h)/2
    print(f"area of the tringle is {ar}")

print("reading arguements for rectangle")
l = float(input("enter the length"))
b = float(input("enter the breadth"))
area_rect(l,b)

print("reading arguements for square")
s = float(input("enter the sides in cms"))
area_Square(s)

print("reading arguements for the circle")
r = float(input("enter the radius"))
area_circle(r)

print("reading arguements for triangle")
b = float(input("enter the base"))
h = float(input("enter the height"))
area_triangle(b,h)