t1 =(1,2,5,7,9,2,4,6,8,10)
t2 =(11,13,15)

tp1 = t1[:5]
tp2 = t1[5:]

print("the first half of the tupel is ")
print(tp1)

print("the second half of the tuple is")
print(tp2)

list = list()
for x in t1:
    if x % 2 == 0:
        list.append(x)
print("tuple with even values")
tp3 = tuple (list)
print(tp3)

print("tuple concAtination")
t1 = t1+t2
print(t1)

print("maximum and min values")
print(max(t1))
print(min(t2))

