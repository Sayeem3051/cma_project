def letter_frequency(sentence):
    frequency_dict = {}

    for char in sentence :
        if char.isalpha():
            char = char.lower()

            if char in frequency_dict:
                frequency_dict[char]+= 1
            else:
                frequency_dict[char] = 1
    return frequency_dict

sentence = input("enter a sentence :")
result  = letter_frequency(sentence)
print(result)
