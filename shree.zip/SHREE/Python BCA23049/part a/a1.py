def find_unique (checklist):
    unique_list = []
    for item in checklist:
        if item not in unique_list:
            unique_list.append(item)
    return unique_list

n = int(input("enter the number of elements in the list"))

listA = []
print(f"enter any {n} elements :")
for i in range (n):
    element = input("enter an element:")
    listA.append(element)

list_unique = find_unique(listA)

print("the unique elements are :",list_unique)