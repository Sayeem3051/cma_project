function clearScreen()
{
	document.getElementById("result").value = "";
}
var op1;
var op2;
var op3;

function display(value)
{	if((value==="+"||value==="/"||value==="*")&&document.getElementById("result").value!="")
	{
		op1=document.getElementById("result").value;
		opr=value;
		clearScreen();
		return;
	}
	if((value==="+"||value==="/"||value==="*")&&document.getElementById("result").value==="")
	{
		return;
	}
	if(value==="-"&&document.getElementById("result").value==="")
	{
		
		document.getElementById("result").value+=value;
		return;
	}
	else if(value==="-"&&document.getElementById("result").value!="")
	{
		
		if(document.getElementById("result").value==="-");
		return;
		op1=document.getElementById("result").value;
		opr=value;
		clearScreen();
		return;
	}
	
	document.getElementById("result").value += value;
}
function displaydot(value)
{
	if(!document.getElementById("result").value.includes("."))
		document.getElementById("result").value+=value;
}
function calculate()
{
	op2=document.getElementById("result").value;
	var exp;
	if(opr==="-"&&op2.includes("-"))
	exp=op1.concat(opr,"(",op2,")");
	else
		exp=op1.concat(opr,op2);
	if(op2==="0"&& opr==="/")
		document.getElementById("result").value="divided by zero error";
	else{
	var q = eval(exp);
	document.getElementById("result").value = q;
	}
}
